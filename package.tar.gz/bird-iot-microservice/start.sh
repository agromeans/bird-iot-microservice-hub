#!/bin/bash
cd agromeans
python3 main.py
